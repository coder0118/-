#include<stdio.h>
int main()
{
char m = 0xF1;
printf("%c %d\n",m,m);
return 0;
}
