#include<stdio.h>
int main()
{
  short int x_year;
  unsigned char x_month, x_day, Sum_day=0;
  printf("please enter year:\n");
  scanf("%d",&x_year);
  printf("please enter month:\n");
  scanf("%d",&x_month);
  printf("please enter day:\n");
  scanf("%d",&x_day);

  unsigned char num_months[12] = {31,28,31,30,31,30,31,31,30,31,30,31};  

  if(x_year%4==0&&x_year%100!=0||x_year%400==0)
  {
	for(int a = 1; a < x_month;a++)
	{
	  Sum_day += num_months[a];
	}
	if(x_month>2)
	{
	printf("Leap year! Sum day is: %d\n",Sum_day+x_day+1);
	}
  }else{
	for(int b = 1;b < x_month;b++)
	{
	Sum_day += num_months[b];
        }
	printf("Ordinary year! Sum day is: %d\n",Sum_day+x_day);
  }
return 0;
}

