#include<stdio.h>
int main()
{
unsigned char a = 128;
double b = 35.254;
printf("%d	%lf\n",a,b);
return 0;
}
