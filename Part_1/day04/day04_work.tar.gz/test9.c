#include<stdio.h>
int main()
{
double n = 3.321;
char m = 6;
printf("sum= %lf\n",n+m);
return 0;
}
