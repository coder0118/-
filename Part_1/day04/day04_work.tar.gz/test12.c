#include<stdio.h>
int main()
{
char n = -128;
printf("%x %d",n-1,n-1);
return 0;
}
