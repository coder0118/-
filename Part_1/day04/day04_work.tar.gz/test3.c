#include<stdio.h>
int main()
{
unsigned int a = 164;
printf("decimalism  %d \n",a);
printf("hexadecimal  %x \n",a);
printf("octonary %o \n",a);
return 0;
}
